/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/** README
 * Author: Jai Singh / ic22b037
 * Assignment Number: 183726
 *
 */


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BLINKY_START_CHAR 'b'
#define BLINKY_STOP_CHAR 's'
#define BLINKY_PERIOD_BASE 400 //ms
#define BLINKY_ON_TIME_BASE 100 //ms
#define RX_BUFFER_SIZE (uint8_t)100
#define TX_BUFFER_SIZE (uint16_t)100
#define UART_TRANSMIT_TIMEOUT (uint32_t)1000
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
char rx_buffer[RX_BUFFER_SIZE];
char tx_buffer[TX_BUFFER_SIZE];
uint16_t chosen_LED = 0;
uint32_t period_multiplicator = 0;
uint32_t on_time_multiplicator = 0;
uint8_t blinkyBlink = 0; // 0 if LED should not blink, 1 if LED goes blink
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void blinky(GPIO_TypeDef* GPIO_Port, uint16_t GPIO_Pin, uint16_t on_time, uint16_t off_time){
	if (HAL_GPIO_ReadPin(GPIO_Port, GPIO_Pin) == GPIO_PIN_RESET && TIM6->CNT >= on_time){
		HAL_GPIO_WritePin(GPIO_Port, GPIO_Pin, GPIO_PIN_SET);
		TIM6->CNT = 0;
	}
	if (HAL_GPIO_ReadPin(GPIO_Port, GPIO_Pin) == GPIO_PIN_SET && TIM6->CNT >= off_time){
		HAL_GPIO_WritePin(GPIO_Port, GPIO_Pin, GPIO_PIN_RESET);
		TIM6->CNT = 0;
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */

  // start timer
  HAL_TIM_Base_Start(&htim6);

  back2start:

  // initially turn off LEDs
    HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, LED_GREEN_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, LED_BLUE_Pin, GPIO_PIN_SET);

  // choose LED
  sprintf(tx_buffer, "\n\rChoose an LED to control: (1) red, (2) green, (3) blue\n\r");
  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

  if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, HAL_MAX_DELAY) == HAL_OK) {
	  chosen_LED = atoi(rx_buffer);
      sprintf(tx_buffer, "\rReceived LED: %d\n\r", chosen_LED);
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

	  switch(chosen_LED) {
	  // set pin number to chosen_LED
	  	      case 1:
	  	    	  chosen_LED = LED_RED_Pin;
	  	    	  break;
	  	      case 2:
	  	    	  chosen_LED = LED_GREEN_Pin;
	  	    	  break;
	  	      case 3:
	  	    	  chosen_LED = LED_BLUE_Pin;
	  	    	  break;
	  	      default:
	  	    	  // restart if input is invalid
	  	    	  sprintf(tx_buffer, "\rINVALID INPUT!\n\r");
	  	    	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  	    	  goto back2start; // The controversial classic :P
	  }
  }
  else {
	  sprintf(tx_buffer, "\rUART TIMEOUT!\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  goto back2start;
  }

  // choose period time
  sprintf(tx_buffer, "\n\rEnter a number to set the period of the blinky LED as a multiple of %d ms (0-9)\n\r", BLINKY_PERIOD_BASE);
  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

  if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, HAL_MAX_DELAY) == HAL_OK) {
	  period_multiplicator = atoi(rx_buffer);
      sprintf(tx_buffer, "\rReceived Period Time: %d ms * %d = %d ms\n\r", BLINKY_PERIOD_BASE, (int)period_multiplicator, BLINKY_PERIOD_BASE * (int)period_multiplicator);
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

  }
  else {
	  sprintf(tx_buffer, "UART TIMEOUT!\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  goto back2start;
  }

  // chose on time
  sprintf(tx_buffer, "\n\rEnter a number to set the on-time of the blinky LED as a multiple of %d ms (0-9)\n\r", BLINKY_ON_TIME_BASE);
  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

  if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, HAL_MAX_DELAY) == HAL_OK) {
	  on_time_multiplicator = atoi(rx_buffer);
      sprintf(tx_buffer, "\rReceived on Time: %d ms * %d = %d ms\n\r", BLINKY_ON_TIME_BASE, (int)on_time_multiplicator, BLINKY_ON_TIME_BASE * (int)on_time_multiplicator);
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
  }
  else {
	  sprintf(tx_buffer, "\rUART TIMEOUT!\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  goto back2start;
  }

  // check if on_time is bigger than period (which cant be) and restart if it is
  if (on_time_multiplicator * BLINKY_ON_TIME_BASE > period_multiplicator * BLINKY_PERIOD_BASE){
	  sprintf(tx_buffer, "\r\nERROR! The on time is bigger then the whole period.\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  sprintf(tx_buffer, "\rPlease choose other values!\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  goto back2start;
  }

  sprintf(tx_buffer, "\r\nPress (b) to start blinky (LED)\n\r");
  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
  sprintf(tx_buffer, "\rPress (s) to stop blinky (LED)\n\r");
  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, 1) == HAL_OK) {
		  switch(rx_buffer[0]){
		  case BLINKY_START_CHAR:
			  TIM6->CNT = 0;
			  blinkyBlink = 1;
			  break;
		  case BLINKY_STOP_CHAR:
			  blinkyBlink = 0;
			  break;
		  default:
			  sprintf(tx_buffer, "\rINVALID INPUT!\n\r");
			  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
			  break;
		  }
		  rx_buffer[0] = '\0';
	  }
	  else {
		  // UART_Receive only waits for 1ms to gather the input, then a HAL_TTIMEOUT is returned
		  // if there was no input it should continue the blinky part of the program, and not be stopped
		  // not a perfect solution tho
		  if (blinkyBlink){
		  		  // blink LED
		  		  blinky(GPIOA, chosen_LED, BLINKY_ON_TIME_BASE * on_time_multiplicator, (BLINKY_PERIOD_BASE * (int)period_multiplicator) - (BLINKY_ON_TIME_BASE * (int)on_time_multiplicator));
		  }
		  else {
			  // turn off LED
			  HAL_GPIO_WritePin(GPIOA, chosen_LED, GPIO_PIN_SET);
		  }
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 4000;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 65535;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_BLUE_Pin|LED_RED_Pin|LED_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_BLUE_Pin LED_RED_Pin LED_GREEN_Pin */
  GPIO_InitStruct.Pin = LED_BLUE_Pin|LED_RED_Pin|LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
