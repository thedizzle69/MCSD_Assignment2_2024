/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/** README
 * Author: Jai Singh / ic22b037
 * Assignment Number: 183726
 *
 */


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ON_CHAR 'q'
#define OFF_CHAR 'w'
#define TOGGLE_CHAR 'e'
#define RX_BUFFER_SIZE (uint8_t)100
#define TX_BUFFER_SIZE (uint16_t)100
#define UART_TRANSMIT_TIMEOUT (uint32_t)1000
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
char rx_buffer[RX_BUFFER_SIZE];
char tx_buffer[TX_BUFFER_SIZE];
uint16_t chosen_LED = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  // initially turn off LEDs
  HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOA, LED_GREEN_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOA, LED_BLUE_Pin, GPIO_PIN_SET);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  // send current status
	  sprintf(tx_buffer, "\n\rCurrent Status: ");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  sprintf(tx_buffer, "\n\r\tRED: %s", (HAL_GPIO_ReadPin(LED_RED_GPIO_Port, LED_RED_Pin) ? "off" : "on"));
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  sprintf(tx_buffer, "\n\r\tGREEN: %s", (HAL_GPIO_ReadPin(LED_GREEN_GPIO_Port, LED_GREEN_Pin) ? "off" : "on"));
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  sprintf(tx_buffer, "\n\r\tBLUE: %s\n", (HAL_GPIO_ReadPin(LED_BLUE_GPIO_Port, LED_BLUE_Pin) ? "off" : "on"));
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

	  sprintf(tx_buffer, "\n\rChoose an LED to control: (1) red, (2) green, (3) blue\n\r");
	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

	  if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, HAL_MAX_DELAY) == HAL_OK) {
		  chosen_LED = atoi(rx_buffer);
	      sprintf(tx_buffer, "\rReceived Input: %d\n\r", chosen_LED);
		  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);

		  switch(chosen_LED) {
		  // set pin number to chosen_LED
		  	      case 1:
		  	    	  chosen_LED = LED_RED_Pin;
		  	    	  break;
		  	      case 2:
		  	    	  chosen_LED = LED_GREEN_Pin;
		  	    	  break;
		  	      case 3:
		  	    	  chosen_LED = LED_BLUE_Pin;
		  	    	  break;
		  	      default:
		  	    	  // restart loop if input is invalid
		  	    	  sprintf(tx_buffer, "\rINVALID INPUT!\n\r");
		  	    	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
		  	    	  continue;
		  	      }

	      sprintf(tx_buffer, "\n\rPress (q) to turn on LED\n\rPress (w) to turn off LED\n\rPress (e) to toggle LED\n\r");
	      HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	      if (HAL_UART_Receive(&huart2, (uint8_t*)rx_buffer, 1, HAL_MAX_DELAY) == HAL_OK) {
	    	  switch(rx_buffer[0]) {
	    	  case ON_CHAR:
	    		  HAL_GPIO_WritePin(GPIOA, chosen_LED, GPIO_PIN_RESET);
	    		  break;
	    	  case OFF_CHAR:
	    		  HAL_GPIO_WritePin(GPIOA, chosen_LED, GPIO_PIN_SET);
	    		  break;
	    	  case TOGGLE_CHAR:
	    		  HAL_GPIO_TogglePin(GPIOA, chosen_LED);
	    		  break;
	    	  default:
	    		  sprintf(tx_buffer, "\rINVALID INPUT!\n\r");
	    		  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	    	  }
	      }
	      else {
	    	  sprintf(tx_buffer, "\rUART TIMEOUT!\n\r");
	    	  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	      }
	  }
	  else {
		  sprintf(tx_buffer, "\rUART TIMEOUT!\n\r");
		  HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), UART_TRANSMIT_TIMEOUT);
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_BLUE_Pin|LED_RED_Pin|LED_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_BLUE_Pin LED_RED_Pin LED_GREEN_Pin */
  GPIO_InitStruct.Pin = LED_BLUE_Pin|LED_RED_Pin|LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
